# Violation Register (Smart Traffic Violation Logger)

Flask + SQLAlchemy (SQLite) + Flask-Login + QR codes + Bootstrap.
Two sides: officers (record and manage violations) and citizens (view and pay their own challans).

## Run (Windows, in the VS Code terminal)

    python -m venv venv
    venv\Scripts\activate
    pip install -r requirements.txt
    python app.py

## Run (macOS / Linux)

    python3 -m venv venv
    source venv/bin/activate
    pip install -r requirements.txt
    python app.py

The browser opens automatically. Sample data is loaded on the first run.

## Demo logins
    Officer  (Officer tab) :  officer / police123
    Citizen  (Citizen tab) :  ravi / ravi123      (vehicles TN09AB1234, TN22EF9090)
    Citizen  (Citizen tab) :  meena / meena123    (vehicle TN10CD5678)

Citizens can also create their own account from the Citizen tab ("Create a citizen account").

## Reset the sample data
Stop the server, delete the `instance` folder, and run `python app.py` again.

## Scanning the QR from a phone
Phone and PC must be on the same Wi-Fi. The QR automatically uses your PC's network address.
If it does not open, allow Python through the firewall when Windows asks.
