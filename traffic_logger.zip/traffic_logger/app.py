"""Smart Traffic Violation Logger - Flask app (SQLAlchemy + SQLite, QR challans)."""
import io
import os
import re
import socket
import threading
import webbrowser
from datetime import date, datetime, timedelta
from functools import wraps

import qrcode
from flask import (Flask, abort, flash, redirect, render_template, request,
                   send_file, url_for)
from flask_login import (LoginManager, UserMixin, current_user, login_required,
                         login_user, logout_user)
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import inspect, text
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-secret-change-me")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///violations.db"
db = SQLAlchemy(app)

login_manager = LoginManager(app)
login_manager.login_view = "login"
login_manager.login_message = "Please sign in first."
login_manager.login_message_category = "warning"

VIOLATION_TYPES = ["No Helmet", "Overspeeding", "Signal Jumping", "Wrong Parking",
                   "No Seat Belt", "Drunk Driving", "No Licence", "Other"]


# ---------------------------------------------------------------- models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(10), nullable=False, default="officer")   # "officer" or "citizen"
    vehicles = db.Column(db.String(200), nullable=False, default="")     # citizens: comma-separated plates


class Violation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    vehicle_number = db.Column(db.String(20), nullable=False, index=True)
    violation_type = db.Column(db.String(50), nullable=False)
    location = db.Column(db.String(120), nullable=False)
    date = db.Column(db.Date, nullable=False)
    fine_amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(10), nullable=False, default="Unpaid")


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


def clean_vehicle(value):
    return re.sub(r"[\s\-]", "", value or "").upper()


def lan_ip():
    """This computer's address on the local network (so a phone can open the QR link)."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("10.255.255.255", 1))
        return sock.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        sock.close()


def public_url(vid):
    """Address stored in the QR code. If the app was opened as localhost, use the LAN IP instead."""
    host = request.host
    if host.split(":")[0] in ("127.0.0.1", "localhost"):
        port = host.partition(":")[2]
        host = lan_ip() + (f":{port}" if port else "")
    return f"{request.scheme}://{host}{url_for('public_status', vid=vid)}"


def read_form(form):
    """Return (data, error). Keeps bad input from crashing the app."""
    try:
        data = dict(
            vehicle_number=clean_vehicle(form["vehicle_number"]),
            violation_type=form["violation_type"],
            location=form["location"].strip(),
            date=datetime.strptime(form["date"], "%Y-%m-%d").date(),
            fine_amount=float(form["fine_amount"]),
        )
    except (KeyError, ValueError):
        return None, "Please fill every field with a valid value."
    if not data["vehicle_number"] or not data["location"] or data["fine_amount"] < 0:
        return None, "Please fill every field with a valid value."
    return data, None


def role_required(role, fallback):
    """Allow only logged-in users of one role; send everyone else to their own side."""
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if current_user.role != role:
                flash(f"That page is for {role}s only.", "warning")
                return redirect(url_for(fallback))
            return view(*args, **kwargs)
        return login_required(wrapped)
    return decorator


officer_required = role_required("officer", "my_challans")
citizen_required = role_required("citizen", "history")


def citizen_plates():
    return [p for p in current_user.vehicles.split(",") if p]


# ------------------------------------------------------------------ auth
@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("home"))
    role = request.values.get("role", "officer")
    if role not in ("officer", "citizen"):
        role = "officer"
    if request.method == "POST":
        user = User.query.filter_by(username=request.form["username"].strip()).first()
        if user and check_password_hash(user.password_hash, request.form["password"]):
            if user.role != role:
                flash(f"That is a {user.role} account. Use the {user.role.title()} tab to sign in.", "warning")
            else:
                login_user(user)
                return redirect(url_for("home"))
        else:
            flash("Wrong username or password.", "danger")
    return render_template("login.html", role=role)


@app.route("/register", methods=["GET", "POST"])
def register():
    """Citizen sign-up: username, password and the vehicle number(s) they own."""
    if current_user.is_authenticated:
        return redirect(url_for("home"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        plates = [clean_vehicle(p) for p in request.form.get("vehicles", "").split(",")]
        plates = [p for p in plates if p]
        if not username or len(password) < 6:
            flash("Enter a username and a password of at least 6 characters.", "danger")
        elif not plates or not all(re.fullmatch(r"[A-Z0-9]{4,15}", p) for p in plates):
            flash("Enter your vehicle number(s), separated by commas.", "danger")
        elif User.query.filter_by(username=username).first():
            flash("That username is already taken.", "danger")
        else:
            user = User(username=username, password_hash=generate_password_hash(password),
                        role="citizen", vehicles=",".join(dict.fromkeys(plates)))
            db.session.add(user)
            db.session.commit()
            login_user(user)
            flash("Account created.", "success")
            return redirect(url_for("home"))
    return render_template("register.html")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("login"))


@app.route("/account", methods=["GET", "POST"])
@officer_required
def account():
    """Change your password or add another officer account."""
    if request.method == "POST":
        action = request.form.get("action")
        if action == "password":
            new = request.form.get("new", "")
            if not check_password_hash(current_user.password_hash, request.form.get("current", "")):
                flash("Your current password is incorrect.", "danger")
            elif len(new) < 6:
                flash("The new password must be at least 6 characters.", "danger")
            elif new != request.form.get("confirm", ""):
                flash("The new passwords do not match.", "danger")
            else:
                current_user.password_hash = generate_password_hash(new)
                db.session.commit()
                flash("Password changed.", "success")
        elif action == "officer":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")
            if not username or len(password) < 6:
                flash("Enter a username and a password of at least 6 characters.", "danger")
            elif User.query.filter_by(username=username).first():
                flash("That username is already taken.", "danger")
            else:
                db.session.add(User(username=username, password_hash=generate_password_hash(password)))
                db.session.commit()
                flash(f"Officer account '{username}' added.", "success")
        return redirect(url_for("account"))
    return render_template("account.html", officers=User.query.order_by(User.username).all())


@app.route("/")
def home():
    if current_user.is_authenticated and current_user.role == "citizen":
        return redirect(url_for("my_challans"))
    return redirect(url_for("history"))


# ---------------------------------------------------------------- create
@app.route("/add", methods=["GET", "POST"])
@officer_required
def add():
    values = {}
    if request.method == "POST":
        data, error = read_form(request.form)
        if error:
            flash(error, "danger")
            values = request.form
        else:
            v = Violation(**data, status="Unpaid")  # always starts as Unpaid
            db.session.add(v)
            db.session.commit()
            flash(f"Challan #{v.id} created.", "success")
            return redirect(url_for("challan", vid=v.id))
    return render_template("form.html", f=values, editing=False, types=VIOLATION_TYPES)


# ------------------------------------------------- read / search / filter
@app.route("/history")
@officer_required
def history():
    q = Violation.query
    vehicle = clean_vehicle(request.args.get("vehicle"))
    vtype = request.args.get("type", "")
    status = request.args.get("status", "")
    d_from = request.args.get("date_from", "")
    d_to = request.args.get("date_to", "")
    try:
        if vehicle:
            q = q.filter(Violation.vehicle_number.contains(vehicle))
        if vtype:
            q = q.filter_by(violation_type=vtype)
        if status:
            q = q.filter_by(status=status)
        if d_from:
            q = q.filter(Violation.date >= datetime.strptime(d_from, "%Y-%m-%d").date())
        if d_to:
            q = q.filter(Violation.date <= datetime.strptime(d_to, "%Y-%m-%d").date())
    except ValueError:
        flash("One of the dates was not valid, so it was ignored.", "warning")
    records = q.order_by(Violation.date.desc(), Violation.id.desc()).all()
    unpaid = [r for r in records if r.status == "Unpaid"]
    summary = dict(count=len(records), unpaid=len(unpaid),
                   outstanding=sum(r.fine_amount for r in unpaid))
    return render_template("history.html", records=records, types=VIOLATION_TYPES,
                           args=request.args, summary=summary)


@app.route("/violation/<int:vid>")
@officer_required
def challan(vid):
    v = db.get_or_404(Violation, vid)
    return render_template("challan.html", v=v,
                           public_url=public_url(v.id))


# ---------------------------------------------------------------- update
@app.route("/violation/<int:vid>/pay", methods=["POST"])
@officer_required
def mark_paid(vid):
    v = db.get_or_404(Violation, vid)
    v.status = "Paid"
    db.session.commit()
    flash(f"Challan #{v.id} marked as paid.", "success")
    return redirect(request.referrer or url_for("history"))


@app.route("/violation/<int:vid>/edit", methods=["GET", "POST"])
@officer_required
def edit(vid):
    v = db.get_or_404(Violation, vid)
    values = dict(vehicle_number=v.vehicle_number, violation_type=v.violation_type,
                  location=v.location, date=v.date.isoformat(),
                  fine_amount=v.fine_amount, status=v.status)
    if request.method == "POST":
        data, error = read_form(request.form)
        if error:
            flash(error, "danger")
            values = request.form
        else:
            for key, val in data.items():
                setattr(v, key, val)
            v.status = "Paid" if request.form.get("status") == "Paid" else "Unpaid"
            db.session.commit()
            flash("Changes saved.", "success")
            return redirect(url_for("challan", vid=v.id))
    return render_template("form.html", f=values, editing=True, v=v, types=VIOLATION_TYPES)


# ---------------------------------------------------------------- delete
@app.route("/violation/<int:vid>/delete", methods=["POST"])
@officer_required
def delete(vid):
    db.session.delete(db.get_or_404(Violation, vid))
    db.session.commit()
    flash(f"Challan #{vid} deleted.", "warning")
    return redirect(url_for("history"))


# ------------------------------------------- QR code + public status page
@app.route("/qr/<int:vid>.png")
def qr(vid):
    v = db.get_or_404(Violation, vid)
    img = qrcode.make(public_url(v.id), box_size=8, border=1)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return send_file(buf, mimetype="image/png")


@app.route("/status")
def status_lookup():
    """Public 'See Status' page: challan number + vehicle number."""
    cid = request.args.get("challan", "").strip()
    plate = clean_vehicle(request.args.get("vehicle"))
    if cid or plate:
        v = db.session.get(Violation, int(cid)) if cid.isdigit() else None
        if v and v.vehicle_number == plate:
            return redirect(url_for("public_status", vid=v.id))
        flash("No challan found with those details.", "danger")
    return render_template("status_lookup.html")


@app.route("/status/<int:vid>")
def public_status(vid):
    return render_template("public_status.html", v=db.get_or_404(Violation, vid))


# ----------------------------------------------------- citizen side
@app.route("/my-challans")
@citizen_required
def my_challans():
    """A citizen sees only the challans of their own vehicle(s)."""
    plates = citizen_plates()
    records = []
    if plates:
        records = (Violation.query.filter(Violation.vehicle_number.in_(plates))
                   .order_by(Violation.status.desc(), Violation.date.desc()).all())  # unpaid first
    unpaid = [r for r in records if r.status == "Unpaid"]
    summary = dict(count=len(records), unpaid=len(unpaid), due=sum(r.fine_amount for r in unpaid))
    return render_template("my_challans.html", records=records, plates=plates, summary=summary)


@app.route("/pay/<int:vid>", methods=["GET", "POST"])
@citizen_required
def pay(vid):
    """Demo payment: no real money moves; confirming marks the challan as Paid."""
    v = db.get_or_404(Violation, vid)
    if v.vehicle_number not in citizen_plates():
        abort(404)
    if v.status == "Paid":
        flash("That challan is already paid.", "warning")
        return redirect(url_for("my_challans"))
    if request.method == "POST":
        if not request.form.get("method"):
            flash("Choose a payment method.", "danger")
        else:
            v.status = "Paid"
            db.session.commit()
            flash(f"Payment of Rs. {v.fine_amount:,.0f} received for challan {v.id:04d}. Thank you.", "success")
            return redirect(url_for("my_challans"))
    return render_template("pay.html", v=v)


# ------------------------------------------------------------------ init
DEMO = [  # plate, type, location, days ago, fine, status
    ("TN09AB1234", "No Helmet", "Anna Salai, Chennai", 4, 500, "Unpaid"),
    ("TN09AB1234", "Wrong Parking", "T Nagar, Chennai", 12, 300, "Unpaid"),
    ("TN09AB1234", "Signal Jumping", "Kathipara Junction", 38, 1000, "Paid"),
    ("TN09AB1234", "Overspeeding", "GST Road, Tambaram", 85, 2000, "Paid"),
    ("TN22EF9090", "No Seat Belt", "OMR, Sholinganallur", 2, 1000, "Unpaid"),
    ("TN22EF9090", "Overspeeding", "ECR near Muttukadu", 25, 2000, "Paid"),
    ("TN10CD5678", "Signal Jumping", "Guindy Junction", 6, 1000, "Unpaid"),
    ("TN10CD5678", "Overspeeding", "Poonamallee High Road", 11, 2000, "Unpaid"),
    ("TN10CD5678", "No Helmet", "Velachery Main Road", 52, 500, "Paid"),
    ("KA01MN4321", "No Licence", "Koyambedu", 44, 5000, "Unpaid"),
    ("KA01MN4321", "Wrong Parking", "Marina Beach Road", 19, 300, "Paid"),
    ("TN07GH2468", "Drunk Driving", "Mount Road", 9, 10000, "Unpaid"),
    ("TN07GH2468", "No Licence", "Adyar Signal", 60, 5000, "Paid"),
    ("TN11JK1357", "Drunk Driving", "Perungudi", 7, 10000, "Unpaid"),
    ("TN11JK1357", "No Helmet", "Medavakkam", 30, 500, "Paid"),
    ("TN01XY7788", "Overspeeding", "Inner Ring Road", 3, 2000, "Unpaid"),
]


def load_demo_data():
    """First run only: one officer, two citizens and sample challans, so there is something to show."""
    db.session.add_all([
        User(username="officer", password_hash=generate_password_hash("police123"), role="officer"),
        User(username="ravi", password_hash=generate_password_hash("ravi123"),
             role="citizen", vehicles="TN09AB1234,TN22EF9090"),
        User(username="meena", password_hash=generate_password_hash("meena123"),
             role="citizen", vehicles="TN10CD5678"),
    ])
    for plate, vtype, place, days_ago, fine, status in DEMO:
        db.session.add(Violation(vehicle_number=plate, violation_type=vtype, location=place,
                                 date=date.today() - timedelta(days=days_ago),
                                 fine_amount=fine, status=status))
    db.session.commit()


def upgrade_old_database():
    """Databases from earlier versions lack the role/vehicles columns; add them in place."""
    cols = {c["name"] for c in inspect(db.engine).get_columns("user")}
    if "role" not in cols:
        db.session.execute(text('ALTER TABLE "user" ADD COLUMN role VARCHAR(10) NOT NULL DEFAULT \'officer\''))
    if "vehicles" not in cols:
        db.session.execute(text('ALTER TABLE "user" ADD COLUMN vehicles VARCHAR(200) NOT NULL DEFAULT \'\''))
    db.session.commit()


with app.app_context():
    db.create_all()
    upgrade_old_database()
    if not User.query.first():
        load_demo_data()

if __name__ == "__main__":
    # With the reloader, the parent process has no WERKZEUG_RUN_MAIN; open the browser once there.
    if not os.environ.get("WERKZEUG_RUN_MAIN"):
        threading.Timer(1.2, lambda: webbrowser.open("http://127.0.0.1:5000")).start()
    # host 0.0.0.0 lets a phone on the same Wi-Fi open the QR link; debug stays off because of that.
    app.run(host="0.0.0.0", port=5000, debug=False, use_reloader=True)
